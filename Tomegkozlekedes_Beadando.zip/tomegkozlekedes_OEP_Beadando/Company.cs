﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tomegkozlekedes_OEP_Beadando
{
    public class Company
    {
        public string name;

        public Company(string name) { this.name = name; }
        public string GetName() { return name; }
    }
}
